"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Plus, Video, Users, Eye, Trash2, Calendar, Clock } from "lucide-react"
import { collection, addDoc, getDocs, query, orderBy, deleteDoc, doc, updateDoc } from "firebase/firestore"
import { db } from "@/lib/firebase"
import type { Subscriber, ZoomMeeting } from "@/lib/types"
import { useToast } from "@/hooks/use-toast"
import { Navigation } from "@/components/navigation"
import { ClientBot } from "@/components/client-bot"

export default function AdminDashboard() {
  const [subscribers, setSubscribers] = useState<Subscriber[]>([])
  const [meetings, setMeetings] = useState<ZoomMeeting[]>([])
  const [loading, setLoading] = useState(false)
  const [isCreateMeetingOpen, setIsCreateMeetingOpen] = useState(false)
  const [isCreateSubscriberOpen, setIsCreateSubscriberOpen] = useState(false)
  const { toast } = useToast()

  // Form states
  const [newSubscriber, setNewSubscriber] = useState({
    name: "",
    email: "",
  })

  const [newMeeting, setNewMeeting] = useState({
    topic: "",
    meetingId: "",
    meetingUrl: "",
    meetingPassword: "",
    startTime: "",
    duration: 60,
    assignedSubscriberId: "",
  })

  useEffect(() => {
    loadSubscribers()
    loadMeetings()
  }, [])

  const loadSubscribers = async () => {
    try {
      const q = query(collection(db, "subscribers"), orderBy("createdAt", "desc"))
      const querySnapshot = await getDocs(q)
      const subscribersList: Subscriber[] = []
      querySnapshot.forEach((doc) => {
        const data = doc.data()
        subscribersList.push({
          id: doc.id,
          ...data,
          createdAt: data.createdAt.toDate(),
        } as Subscriber)
      })
      setSubscribers(subscribersList)
    } catch (error) {
      console.error("Error loading subscribers:", error)
      toast({
        title: "Error",
        description: "Failed to load subscribers",
        variant: "destructive",
      })
    }
  }

  const loadMeetings = async () => {
    try {
      const q = query(collection(db, "meetings"), orderBy("createdAt", "desc"))
      const querySnapshot = await getDocs(q)
      const meetingsList: ZoomMeeting[] = []
      querySnapshot.forEach((doc) => {
        const data = doc.data()
        meetingsList.push({
          id: doc.id,
          ...data,
          startTime: data.startTime.toDate(),
          createdAt: data.createdAt.toDate(),
        } as ZoomMeeting)
      })
      setMeetings(meetingsList)
    } catch (error) {
      console.error("Error loading meetings:", error)
      toast({
        title: "Error",
        description: "Failed to load meetings",
        variant: "destructive",
      })
    }
  }

  const createSubscriber = async () => {
    if (!newSubscriber.name || !newSubscriber.email) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      })
      return
    }

    setLoading(true)
    try {
      await addDoc(collection(db, "subscribers"), {
        ...newSubscriber,
        createdAt: new Date(),
        isActive: true,
      })

      setNewSubscriber({ name: "", email: "" })
      setIsCreateSubscriberOpen(false)
      loadSubscribers()

      toast({
        title: "Success",
        description: "Subscriber created successfully",
      })
    } catch (error) {
      console.error("Error creating subscriber:", error)
      toast({
        title: "Error",
        description: "Failed to create subscriber",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const addExternalMeeting = async () => {
    if (!newMeeting.topic || !newMeeting.meetingId || !newMeeting.meetingUrl || !newMeeting.assignedSubscriberId) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    setLoading(true)
    try {
      const assignedSubscriber = subscribers.find((s) => s.id === newMeeting.assignedSubscriberId)

      // Save externally created meeting to Firebase
      await addDoc(collection(db, "meetings"), {
        meetingId: newMeeting.meetingId,
        meetingUrl: newMeeting.meetingUrl,
        meetingPassword: newMeeting.meetingPassword,
        topic: newMeeting.topic,
        startTime: new Date(newMeeting.startTime),
        duration: newMeeting.duration,
        assignedSubscriberId: newMeeting.assignedSubscriberId,
        assignedSubscriberName: assignedSubscriber?.name || "",
        status: "scheduled",
        createdAt: new Date(),
        botJoined: false,
        isExternal: true,
      })

      setNewMeeting({
        topic: "",
        meetingId: "",
        meetingUrl: "",
        meetingPassword: "",
        startTime: "",
        duration: 60,
        assignedSubscriberId: "",
      })
      setIsCreateMeetingOpen(false)
      loadMeetings()

      toast({
        title: "Success",
        description: "External meeting added successfully",
      })
    } catch (error) {
      console.error("Error adding external meeting:", error)
      toast({
        title: "Error",
        description: "Failed to add external meeting",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const deleteSubscriber = async (id: string) => {
    try {
      await deleteDoc(doc(db, "subscribers", id))
      loadSubscribers()
      toast({
        title: "Success",
        description: "Subscriber deleted successfully",
      })
    } catch (error) {
      console.error("Error deleting subscriber:", error)
      toast({
        title: "Error",
        description: "Failed to delete subscriber",
        variant: "destructive",
      })
    }
  }

  const updateMeetingStatus = async (meetingId: string, status: string) => {
    try {
      await updateDoc(doc(db, "meetings", meetingId), { status })
      loadMeetings()
      toast({
        title: "Success",
        description: "Meeting status updated",
      })
    } catch (error) {
      console.error("Error updating meeting:", error)
      toast({
        title: "Error",
        description: "Failed to update meeting",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navigation />
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Admin Dashboard</h1>
            <p className="text-gray-600 dark:text-gray-300 mt-2">
              Manage meetings, subscribers, and monitor bot activity
            </p>
          </div>
          <div className="flex gap-2">
            <Dialog open={isCreateSubscriberOpen} onOpenChange={setIsCreateSubscriberOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" className="flex items-center gap-2 bg-transparent">
                  <Users className="h-4 w-4" />
                  Add Subscriber
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create New Subscriber</DialogTitle>
                  <DialogDescription>Add a new subscriber who can listen to meeting audio streams</DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="name">Name</Label>
                    <Input
                      id="name"
                      value={newSubscriber.name}
                      onChange={(e) => setNewSubscriber({ ...newSubscriber, name: e.target.value })}
                      placeholder="Enter subscriber name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={newSubscriber.email}
                      onChange={(e) => setNewSubscriber({ ...newSubscriber, email: e.target.value })}
                      placeholder="Enter subscriber email"
                    />
                  </div>
                  <Button onClick={createSubscriber} disabled={loading} className="w-full">
                    {loading ? "Creating..." : "Create Subscriber"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>

            <Dialog open={isCreateMeetingOpen} onOpenChange={setIsCreateMeetingOpen}>
              <DialogTrigger asChild>
                <Button className="flex items-center gap-2">
                  <Plus className="h-4 w-4" />
                  Add External Meeting
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>Add External Meeting</DialogTitle>
                  <DialogDescription>
                    Add a Zoom meeting created externally and assign it to a subscriber
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="topic">Meeting Topic</Label>
                    <Input
                      id="topic"
                      value={newMeeting.topic}
                      onChange={(e) => setNewMeeting({ ...newMeeting, topic: e.target.value })}
                      placeholder="Enter meeting topic"
                    />
                  </div>
                  <div>
                    <Label htmlFor="meetingId">Meeting ID</Label>
                    <Input
                      id="meetingId"
                      value={newMeeting.meetingId}
                      onChange={(e) => setNewMeeting({ ...newMeeting, meetingId: e.target.value })}
                      placeholder="Enter Zoom meeting ID"
                    />
                  </div>
                  <div>
                    <Label htmlFor="meetingUrl">Meeting URL</Label>
                    <Input
                      id="meetingUrl"
                      value={newMeeting.meetingUrl}
                      onChange={(e) => setNewMeeting({ ...newMeeting, meetingUrl: e.target.value })}
                      placeholder="Enter Zoom meeting URL"
                    />
                  </div>
                  <div>
                    <Label htmlFor="meetingPassword">Meeting Password (Optional)</Label>
                    <Input
                      id="meetingPassword"
                      value={newMeeting.meetingPassword}
                      onChange={(e) => setNewMeeting({ ...newMeeting, meetingPassword: e.target.value })}
                      placeholder="Enter meeting password if required"
                    />
                  </div>
                  <div>
                    <Label htmlFor="startTime">Start Time</Label>
                    <Input
                      id="startTime"
                      type="datetime-local"
                      value={newMeeting.startTime}
                      onChange={(e) => setNewMeeting({ ...newMeeting, startTime: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="duration">Duration (minutes)</Label>
                    <Input
                      id="duration"
                      type="number"
                      value={newMeeting.duration}
                      onChange={(e) => setNewMeeting({ ...newMeeting, duration: Number.parseInt(e.target.value) })}
                      min="15"
                      max="480"
                    />
                  </div>
                  <div>
                    <Label htmlFor="subscriber">Assign to Subscriber</Label>
                    <Select
                      value={newMeeting.assignedSubscriberId}
                      onValueChange={(value) => setNewMeeting({ ...newMeeting, assignedSubscriberId: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select subscriber" />
                      </SelectTrigger>
                      <SelectContent>
                        {subscribers.map((subscriber) => (
                          <SelectItem key={subscriber.id} value={subscriber.id}>
                            {subscriber.name} ({subscriber.email})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <Button onClick={addExternalMeeting} disabled={loading} className="w-full">
                    {loading ? "Adding..." : "Add Meeting"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <Tabs defaultValue="meetings" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="meetings" className="flex items-center gap-2">
              <Video className="h-4 w-4" />
              Meetings
            </TabsTrigger>
            <TabsTrigger value="subscribers" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Subscribers
            </TabsTrigger>
          </TabsList>

          <TabsContent value="meetings">
            <Card>
              <CardHeader>
                <CardTitle>Meeting Management</CardTitle>
                <CardDescription>View and manage all Zoom meetings and their assignments</CardDescription>
              </CardHeader>
              <CardContent>
                {meetings.filter((m) => m.status === "live").length > 0 && (
                  <div className="mb-6 space-y-4">
                    <h3 className="text-lg font-semibold">Active Meeting Bots</h3>
                    {meetings
                      .filter((m) => m.status === "live")
                      .map((meeting) => (
                        <ClientBot
                          key={meeting.id}
                          meeting={meeting}
                          onStatusChange={(status) => console.log(`Bot status for ${meeting.topic}:`, status)}
                        />
                      ))}
                  </div>
                )}

                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Topic</TableHead>
                      <TableHead>Assigned To</TableHead>
                      <TableHead>Start Time</TableHead>
                      <TableHead>Duration</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Bot Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {meetings.map((meeting) => (
                      <TableRow key={meeting.id}>
                        <TableCell className="font-medium">{meeting.topic}</TableCell>
                        <TableCell>{meeting.assignedSubscriberName}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-gray-400" />
                            {meeting.startTime.toLocaleDateString()}
                            <Clock className="h-4 w-4 text-gray-400 ml-2" />
                            {meeting.startTime.toLocaleTimeString()}
                          </div>
                        </TableCell>
                        <TableCell>{meeting.duration} min</TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              meeting.status === "live"
                                ? "default"
                                : meeting.status === "scheduled"
                                  ? "secondary"
                                  : "outline"
                            }
                          >
                            {meeting.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant={meeting.botJoined ? "default" : "outline"}>
                            {meeting.botJoined ? "Joined" : "Pending"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => window.open(meeting.meetingUrl, "_blank")}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Select
                              value={meeting.status}
                              onValueChange={(value) => updateMeetingStatus(meeting.id, value)}
                            >
                              <SelectTrigger className="w-24">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="scheduled">Scheduled</SelectItem>
                                <SelectItem value="live">Live</SelectItem>
                                <SelectItem value="ended">Ended</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="subscribers">
            <Card>
              <CardHeader>
                <CardTitle>Subscriber Management</CardTitle>
                <CardDescription>Manage subscribers who can listen to meeting audio streams</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Created</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {subscribers.map((subscriber) => (
                      <TableRow key={subscriber.id}>
                        <TableCell className="font-medium">{subscriber.name}</TableCell>
                        <TableCell>{subscriber.email}</TableCell>
                        <TableCell>
                          <Badge variant={subscriber.isActive ? "default" : "outline"}>
                            {subscriber.isActive ? "Active" : "Inactive"}
                          </Badge>
                        </TableCell>
                        <TableCell>{subscriber.createdAt.toLocaleDateString()}</TableCell>
                        <TableCell>
                          <Button size="sm" variant="outline" onClick={() => deleteSubscriber(subscriber.id)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
