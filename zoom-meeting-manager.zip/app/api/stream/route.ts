import { type NextRequest, NextResponse } from "next/server"
import { collection, query, where, getDocs, doc, updateDoc, arrayUnion, arrayRemove } from "firebase/firestore"
import { db } from "@/lib/firebase"

// Store active WebSocket connections
const connections = new Map<string, Set<WebSocket>>()

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const subscriberId = searchParams.get("subscriberId")
    const meetingId = searchParams.get("meetingId")

    if (!subscriberId) {
      return NextResponse.json({ error: "Subscriber ID required" }, { status: 400 })
    }

    // Get meetings assigned to this subscriber
    const q = query(
      collection(db, "meetings"),
      where("assignedSubscriberId", "==", subscriberId),
      ...(meetingId ? [where("meetingId", "==", meetingId)] : []),
    )

    const querySnapshot = await getDocs(q)
    const meetings: any[] = []

    querySnapshot.forEach((doc) => {
      const data = doc.data()
      meetings.push({
        id: doc.id,
        ...data,
        startTime: data.startTime.toDate(),
        createdAt: data.createdAt.toDate(),
      })
    })

    // Filter for active meetings with bot joined
    const activeStreams = meetings.filter((meeting) => meeting.status === "live" && meeting.botJoined)

    return NextResponse.json({
      success: true,
      streams: activeStreams.map((meeting) => ({
        meetingId: meeting.meetingId,
        topic: meeting.topic,
        streamUrl: `${process.env.NODE_ENV === "development" ? "ws://localhost:3000" : "wss://" + request.headers.get("host")}/api/stream/ws?meetingId=${meeting.id}&subscriberId=${subscriberId}`,
        quality: "good",
        isActive: true,
      })),
    })
  } catch (error) {
    console.error("Stream API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const { subscriberId, meetingId, action } = await request.json()

    if (!subscriberId || !meetingId || !action) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Handle stream start/stop for subscriber
    const isStarting = action === "start"

    if (isStarting) {
      await updateDoc(doc(db, "meetings", meetingId), {
        connectedSubscribers: arrayUnion(subscriberId),
      })
    } else {
      await updateDoc(doc(db, "meetings", meetingId), {
        connectedSubscribers: arrayRemove(subscriberId),
      })
    }

    return NextResponse.json({
      success: true,
      action: action,
      streamUrl: isStarting
        ? `${process.env.NODE_ENV === "development" ? "ws://localhost:3000" : "wss://" + request.headers.get("host")}/api/stream/ws?meetingId=${meetingId}&subscriberId=${subscriberId}`
        : null,
      message: `Stream ${isStarting ? "started" : "stopped"} successfully`,
    })
  } catch (error) {
    console.error("Stream control API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
